def binary_to_hex():
    """
    Takes binary input

    divides into 4 bit numbers and converts each index multiplied 
    by it occuring power of 2

    dividant and remainder

    adds re-formed indexes of the divivdants and remaiders together 

    minuses one from number to find right index

    places index in hexadecimal value

    prints both hexadecimal value together for each index to become one hexadecimal value.
    """
    hexadecimal_value = "123456789ABCDEF"
    print("Leave space after every binary number")

    try:
        input_str = input("Enter binary numbers: ")
        input_list = input_str.split(" ")

        if input_str == "":
            print("no input")
        
        #makes sure binary digits are a length of 8 and only contain 0 or 1
        elif all(digit in "01" and len(num) == 8 for num in input_list for digit in num):

            for num in input_list:
                #Adds leading zeros if digits dont reach desired length of 4
                div = "{:04}".format(int(num)//10000)
                rem = "{:04}".format(int(num) % 10000)

                rem_index3 = int(rem[3]) * 1
                rem_index2 = int(rem[2]) * 2
                rem_index1 = int(rem[1]) * 4
                rem_index0 = int(rem[0]) * 8

                div_index3 = int(div[3]) * 1
                div_index2 = int(div[2]) * 2
                div_index1 = int(div[1]) * 4
                div_index0 = int(div[0]) * 8


                sum_rem = rem_index0  + rem_index1 + rem_index2 + rem_index3
                sum_div = div_index0 + div_index1 + div_index2 + div_index3

                #minuses one from div and rem decimal to find right 
                #index since indexes start from 0
                sum_rem = sum_rem - 1
                sum_div = sum_div - 1

                sum_div_character = hexadecimal_value[sum_div]
                sum_rem_character = hexadecimal_value[sum_rem]

                #adds hexadecimal value of dividants and remainders to form one value
                hex_value = sum_div_character + sum_rem_character
                print(hex_value)
        
        else:
            print("Error: Invalid binary input")

    #wont pass if there is no input
    except ValueError:
        print("Error: Please input binary numbers accordingly.")


def binary_to_text():
    """
    Turns binary to decimal value by  multiplying index by
    occuring power of 2

    adds all re informed indexes together to get decimal value

    uses the chr function to turn decimal value to chr(text values) in ASCII chart in python
    """
    try:
        print("Leave space after every binary number")
        input_str = input("Enter binary: ")
        input_list = input_str.split(" ")

        if input_str == "":
            print("no input")

        #makes sure binary digits are a length of 8 and only contain 0 or 1
        elif all(digit in "01" and len(num) == 8 for num in input_list for digit in num):
            for num in input_list:
                #mulplying indexes on binary by corresponding power
                index7 = int(num[7]) * 1
                index6 = int(num[6]) * 2
                index5 = int(num[5]) * 4
                index4 = int(num[4]) * 8
                index3 = int(num[3]) * 16
                index2 = int(num[2]) * 32
                index1 = int(num[1]) * 64
                index0 = int(num[0]) * 128

                sum = index0 + index1 + index2 + index3 + index4 + index5 + index6 + index7

                #changes index to character(text) in ASCII chart
                text_value = chr(sum)
                print(text_value)
        else:
            print("Error: Invalid binary input")        

    except ValueError:
        print("Error: Please put spaces between binary numbers.")
        
def binary_to_ascii():
    """
    Takes binary number and converts to decimal by multiplying by corresponding
    power.

    adds re-formed indexes together to get ascii decimal value
    """
    try:
        print("Leave space after every binary number")
        input_str = input("Enter binary: ")
        #splits each multiple binary number after space into individual numbers
        input_list = input_str.split(" ")
        if input_str == "":
            print("no input")

        #makes sure all inputs contain 0 and 1 and is a length of 8
        elif all(digit in "01" and len(num) == 8 for num in input_list for digit in num):
            for num in input_list:
                #calculates decimal value of each digit
                index7 = int(num[7]) * 1
                index6 = int(num[6]) * 2
                index5 = int(num[5]) * 4
                index4 = int(num[4]) * 8
                index3 = int(num[3]) * 16
                index2 = int(num[2]) * 32
                index1 = int(num[1]) * 64
                index0 = int(num[0]) *128

                #adds to get ascii decimal value of binary
                sum = index0 + index1 + index2 + index3 + index4 + index5 + index6 + index7
                ascii_value = sum
                print(ascii_value)
        else:
            print("Error: Invalid binary input")        

    except ValueError:
        print("Error: Please put spaces between binary numbers.")

def binary_to_uni():
    """
    Takes binary input and seperates iinto half

    dividant and remainder

    converts both dividant and remainder into decimals

    looks for the decimal index in hexvalue chart

    adds unicode format unto hexadecimal value
    """
    hexadecimal_value = "123456789ABCDEF"
    print("Leave space after every binary number")

    try:
        input_str = input("Enter binary numbers: ")
        input_list = input_str.split(" ")

        if input_str == "":
            print("no input")
        
        #makes sure binary digits are a length of 8 and only contain 0 or 1
        elif all(digit in "01" and len(num) == 8 for num in input_list for digit in num):

            for num in input_list:
                #adds leading zeros unto input value if the length is not up to 4
                #seperates 8bit binary into two "4 digit" binary numbers
                div = "{:04}".format(int(num)//10000)
                rem = "{:04}".format(int(num) % 10000)

                rem_index3 = int(rem[3]) * 1
                rem_index2 = int(rem[2]) * 2
                rem_index1 = int(rem[1]) * 4
                rem_index0 = int(rem[0]) * 8

                div_index3 = int(div[3]) * 1
                div_index2 = int(div[2]) * 2
                div_index1 = int(div[1]) * 4
                div_index0 = int(div[0]) * 8

                #adds to find decimal value of each binary half (dividant and rem)
                sum_rem = rem_index0  + rem_index1 + rem_index2 + rem_index3
                sum_div = div_index0 + div_index1 + div_index2 + div_index3

                sum_rem = sum_rem - 1
                sum_div = sum_div - 1

                #looks for number index in hexadecimal string
                sum_div_character = hexadecimal_value[sum_div]
                sum_rem_character = hexadecimal_value[sum_rem]

                hex_value = sum_div_character + sum_rem_character

                #adds U+ and 00 un hexadecimal to get unicode format
                zero = "00"
                uni = "U+"
                uni_value = uni + zero + hex_value
                print(uni_value)
        
        else:
            print("Error: Invalid binary input")

    except ValueError:
        print("Error: input binary number .")

def hex_to_binary():
    """
    Takes input and converts to uppercase

    takes each individual digit of the 2-digit hex value

    turns hex to full number digits by yaking its index and finding the num index value in hex_values

    looks for sum of div and rem value in power_list and turns them to 1 and the rest to 0
    to get binar number
    """
    try:
        input_str = input("Enter hexadecimal with a space after each one: ")
        input_list = input_str.split(" ")
        #converts all alphabets to uppercase when inputed
        input_list = [hex.upper() for hex in input_list]

        if input_str == "":
            print("no input: Please input hexadecimal")

        #makes sure all inputs are 2digits long
        elif all(len(num) == 2 for num in input_list):
            hex_values = "123456789ABCDEF"
            #numbers used in sum to find binary
            power_list = [8, 4, 2, 1]

            for value in input_list:
                binary_num = ""
                binary_num_2 = ""
                div = value[0]
                rem = value[1]

                find_div = hex_values.index(div)
                find_rem = hex_values.index(rem)
                
                #adds one for index correction
                find_div = find_div + 1
                find_rem = find_rem + 1
                    
                #takes sum in power_list that equals value and converts it to 1 for dividant
                for power in power_list:
                    if find_div >= power:
                        binary_num += "1"
                        find_div -= power
                    #takes other numbers that arent used and converts it to 0 for dividant
                    else:
                        binary_num += "0"
                #takes sum in power_list that equals value and converts it to 1 for remainder
                    if find_rem >= power:
                        binary_num_2 += "1"
                        find_rem -= power
                    #takes other numbers that arent used and converts it to 0 for remainder
                    else:
                        binary_num_2 += "0"
                
                #joins together to get final binary value
                binary = binary_num + (binary_num_2)
                print(binary)
        else:
            print("Invalid input: Please enter hexadecimal")    

    except ValueError:
        print("Error: Please put spaces between each hexadecmal.")

def hex_to_text():
    """
    converts hex to binary first using the method above

    takes binary value and converts to decimal by 
    multiplying specific indexes of binary by corresponding power of 2

    takes re-formed indexes and adds them together to get decimal value

    uses char function to convert decimal to ascii chr(txt) in ascii chart in python
    """
    try:
        input_str = input("Enter hexadecimal with a space after each one: ")
        input_list = input_str.split(" ")
        #converts input alphabets to uppercase
        input_list = [hex.upper() for hex in input_list]

        if input_str == "":
            print("no input: Please input hexadecimal")

        #makes sure all inputs are 2digits long
        elif all(len(num) == 2 for num in input_list):
            hex_values = "0123456789ABCDEF"
            power_list = [8, 4, 2, 1]

            for value in input_list:
                binary_num = ""
                binary_num_2 = ""

                #takes specific digits in input and calculates each seperately
                div = value[0]
                rem = value[1]

                find_div = hex_values.index(div)
                find_rem = hex_values.index(rem)
                
                #used to find binary in each specific hex_index from input
                for power in power_list:
                    if find_div >= power:
                        binary_num += "1"
                        find_div -= power
                    else:
                        binary_num += "0"

                    if find_rem >= power:
                        binary_num_2 += "1"
                        find_rem -= power
                    else:
                        binary_num_2 += "0"
                
                binary = binary_num + binary_num_2

                #makes sure the binary length is 8
                for digits in range(0, len(binary), 8):
                    for num in [binary[digits:digits+ 8]]:
                        #multiplies by powers of 2 to fond decimal values
                        index7 = int(num[7]) * 1
                        index6 = int(num[6]) * 2
                        index5 = int(num[5]) * 4
                        index4 = int(num[4]) * 8
                        index3 = int(num[3]) * 16
                        index2 = int(num[2]) * 32
                        index1 = int(num[1]) * 64
                        index0 = int(num[0]) * 128
                    
                    #adds to get total decimal value of full binary
                    add = index7 + index6 + index5 + index4 + index3 + index2 + index1 + index0

                    #converts to text using built in python function chr
                    text = chr(add)
                    print(text)

        else:
            print("Invalid input: Please enter hexadecimal")    

    except ValueError:
        print("Error: Please put spaces between each hexadecmal.")


def hex_to_ascii():
    """
    Uses the same method above but without chr() function

    converts to binary value using sums in power_list

    converts from binary to decimal value using powers of two

    adds all re-formed indexes together to get ascii decimal value
    """
    try:
        input_str = input("Enter hexadecimal with a space after each one: ")
        input_list = input_str.split(" ")
        #makes sure all input alphabets are uppercase
        input_list = [hex.upper() for hex in input_list]

        if input_str == "":
            print("no input: Please input hexadecimal")

        #makes sure all inputs are 2digits long
        elif all(len(num) == 2 for num in input_list):
            hex_values = "0123456789ABCDEF"
            power_list = [8, 4, 2, 1]

            for value in input_list:
                binary_num = ""
                binary_num_2 = ""
                div = value[0]
                rem = value[1]

                #converts to get digits and switch out letters
                find_div = hex_values.index(div)
                find_rem = hex_values.index(rem)
                
                #converts to binary
                for power in power_list:
                    if find_div >= power:
                        binary_num += "1"
                        find_div -= power
                    else:
                        binary_num += "0"

                    if find_rem >= power:
                        binary_num_2 += "1"
                        find_rem -= power
                    else:
                        binary_num_2 += "0"
                
                binary = binary_num + binary_num_2

                #makes sure bianry is 8 digits long
                for digits in range(0, len(binary), 8):
                    for num in [binary[digits:digits+ 8]]:

                        #converts to decimal for eac index using powers of 2
                        index7 = int(num[7]) * 1
                        index6 = int(num[6]) * 2
                        index5 = int(num[5]) * 4
                        index4 = int(num[4]) * 8
                        index3 = int(num[3]) * 16
                        index2 = int(num[2]) * 32
                        index1 = int(num[1]) * 64
                        index0 = int(num[0]) * 128
                    
                    #adds all indexes tigether to get decimal ascii value
                    add = index7 + index6 + index5 + index4 + index3 + index2 + index1 + index0
                    ascii = add
                    print(ascii)

        else:
            print("Invalid input: Please enter hexadecimal")    

    except ValueError:
        print("Error: Please put spaces between each hexadecmal.")

def hex_to_uni():
    """
    takes hexadecimal value and converts to unicode 
    format by adding U+ and 00 in front of input
    """
    try:
        input_str = input("Enter hexadecimal with a space after each one: ")
        input_list = input_str.split(" ")
        #makes sure all alphabets in input are uppercase
        input_list = [hex.upper() for hex in input_list]

        if input_str == "":
            print("no input: Please input hexadecimal")

        #makes sure all inputs are 2digits long
        elif all(len(num) == 2  for num in input_list):
            for num in input_list:
                #defines strings "00" and "U+"
                zero = "00"
                uni = "U+"

                #adds strings in order in front of input value to print unicode format
                uni_hex = uni + zero + num
                print(uni_hex)
           
        else:
            print("Invalid input: Please enter hexadecimal")    

    except ValueError:
        print("Error: Please put spaces between each hexadecmal.")

def text_to_binary():
    """
    takes text input and converts to ascii deicmal by swiching it to its key in the 
    ascii_table dictionary

     takes decimal value and finds sum in power list and turns it to 1
     and turns the unused digits to 0 to get binary number
    """
    input_str = input("Enter text ")
    input_list = input_str.split(" ")

    if input_str == "":
        print("no input")
    
    #makes sure input accepts, letters and special keyboard characters
    elif all(txt.isalnum() or txt.isspace() or txt in "!@#$%^&*()_+-=[]{}|;:'\",.<>?/" for txt in input_str):
        #defines asci characters to corresponding decimal value
        ascii_table = {
            0: 'NUL', 1: 'SOH', 2: 'STX', 3: 'ETX', 4: 'EOT', 5: 'ENQ', 6: 'ACK', 7: 'BEL',
            8: 'BS', 9: 'TAB', 10: 'LF', 11: 'VT', 12: 'FF', 13: 'CR', 14: 'SO', 15: 'SI',
            16: 'DLE', 17: 'DC1', 18: 'DC2', 19: 'DC3', 20: 'DC4', 21: 'NAK', 22: 'SYN', 23: 'ETB',
            24: 'CAN', 25: 'EM', 26: 'SUB', 27: 'ESC', 28: 'FS', 29: 'GS', 30: 'RS', 31: 'US',
            32: ' ', 33: '!', 34: '"', 35: '#', 36: '$', 37: '%', 38: '&', 39: "'",
            40: '(', 41: ')', 42: '*', 43: '+', 44: ',', 45: '-', 46: '.', 47: '/',
            48: '0', 49: '1', 50: '2', 51: '3', 52: '4', 53: '5', 54: '6', 55: '7',
            56: '8', 57: '9', 58: ':', 59: ';', 60: '<', 61: '=', 62: '>', 63: '?',
            64: '@', 65: 'A', 66: 'B', 67: 'C', 68: 'D', 69: 'E', 70: 'F', 71: 'G',
            72: 'H', 73: 'I', 74: 'J', 75: 'K', 76: 'L', 77: 'M', 78: 'N', 79: 'O',
            80: 'P', 81: 'Q', 82: 'R', 83: 'S', 84: 'T', 85: 'U', 86: 'V', 87: 'W',
            88: 'X', 89: 'Y', 90: 'Z', 91: '[', 92: '\\', 93: ']', 94: '^', 95: '_',
            96: '`', 97: 'a', 98: 'b', 99: 'c', 100: 'd', 101: 'e', 102: 'f', 103: 'g',
            104: 'h', 105: 'i', 106: 'j', 107: 'k', 108: 'l', 109: 'm', 110: 'n', 111: 'o',
            112: 'p', 113: 'q', 114: 'r', 115: 's', 116: 't', 117: 'u', 118: 'v', 119: 'w',
            120: 'x', 121: 'y', 122: 'z', 123: '{', 124: '|', 125: '}', 126: '~', 127: 'DEL',
        }

        for word in input_list:
            for letter in word:
                found = False
                for key, value in ascii_table.items():
                    if value == letter:
                        #converts input to corresponding key in ascii_table dictionary
                        text_ascii = key
                        #this is to makes sure code knows a match has been found
                        found = True
                        #this is to makes sure erminal doesnt print every other non
                        #corresponding key as an error
                        break
                if not found:
                        print("Value not found in ASCII conversions")
                        continue

                power_list = [64, 32, 16, 8, 4, 2, 1]
                binary_txt = "0"

                #takes decimal and finds sum in power_list and turns it to one
                for power in power_list:
                    if text_ascii >= power:
                        binary_txt += "1"
                        text_ascii -= power
                    #turns unused digits in sum to 0 to find binary
                    else:
                        binary_txt += "0"
                    
                print(binary_txt)
    else:
        print("Invalid input: please enter text")

def text_to_hex():
    """
    converts text to ascii decimal first using methid above

    akes ascii decimal and divides by 16 to get div and remainder
    looks for div index and remainder index in hexadecimal_value string

    prints indexes value added to get final hex value
    """
    input_str = input("Enter text: ")
    input_list = input_str.split(" ")  

    if input_str == "":
        print("no input") 
    
    #makes sure input accepts letters and special key characters
    elif all(txt.isalnum() or txt.isspace() or txt in "!@#$%^&*()_+-=[]{}|;:'\",.<>?/" for txt in input_str):
        #defines hexadecimal values and ascii conversions
        hexadecimal_value = "123456789ABCDEF"  
        ascii_table = {
            0: 'NUL', 1: 'SOH', 2: 'STX', 3: 'ETX', 4: 'EOT', 5: 'ENQ', 6: 'ACK', 7: 'BEL',
            8: 'BS', 9: 'TAB', 10: 'LF', 11: 'VT', 12: 'FF', 13: 'CR', 14: 'SO', 15: 'SI',
            16: 'DLE', 17: 'DC1', 18: 'DC2', 19: 'DC3', 20: 'DC4', 21: 'NAK', 22: 'SYN', 23: 'ETB',
            24: 'CAN', 25: 'EM', 26: 'SUB', 27: 'ESC', 28: 'FS', 29: 'GS', 30: 'RS', 31: 'US',
            32: ' ', 33: '!', 34: '"', 35: '#', 36: '$', 37: '%', 38: '&', 39: "'",
            40: '(', 41: ')', 42: '*', 43: '+', 44: ',', 45: '-', 46: '.', 47: '/',
            48: '0', 49: '1', 50: '2', 51: '3', 52: '4', 53: '5', 54: '6', 55: '7',
            56: '8', 57: '9', 58: ':', 59: ';', 60: '<', 61: '=', 62: '>', 63: '?',
            64: '@', 65: 'A', 66: 'B', 67: 'C', 68: 'D', 69: 'E', 70: 'F', 71: 'G',
            72: 'H', 73: 'I', 74: 'J', 75: 'K', 76: 'L', 77: 'M', 78: 'N', 79: 'O',
            80: 'P', 81: 'Q', 82: 'R', 83: 'S', 84: 'T', 85: 'U', 86: 'V', 87: 'W',
            88: 'X', 89: 'Y', 90: 'Z', 91: '[', 92: '\\', 93: ']', 94: '^', 95: '_',
            96: '`', 97: 'a', 98: 'b', 99: 'c', 100: 'd', 101: 'e', 102: 'f', 103: 'g',
            104: 'h', 105: 'i', 106: 'j', 107: 'k', 108: 'l', 109: 'm', 110: 'n', 111: 'o',
            112: 'p', 113: 'q', 114: 'r', 115: 's', 116: 't', 117: 'u', 118: 'v', 119: 'w',
            120: 'x', 121: 'y', 122: 'z', 123: '{', 124: '|', 125: '}', 126: '~', 127: 'DEL',
        }

        for word in input_list:
            for letter in word:
                found = False
                for key, value in ascii_table.items():
                    if value == letter:
                        text_ascii = key
                        found = True
                        break
                if not found:
                        print("Value not found in ASCII conversions")
                        continue
                try:
                    #divides asci decimal to get two seperate values dividant and remainder
                    div = text_ascii // 16
                    rem = text_ascii % 16

                    #minuses to get correct index since index starts from 0
                    div = div - 1
                    rem = rem - 1

                    #looks for hex value of digits thru index
                    div_hex = hexadecimal_value[div]
                    rem_hex = hexadecimal_value[rem]

                    #adds both hex value of digits together ti get final hex_value
                    hex = div_hex + rem_hex
                    print(hex)

                except ValueError:
                    print("Error: trying to convert a non-integer string to an integer")
    else:
        print("Invalid input: please enter text")


def text_to_ascii():
    """
    looks for ascii decimal in ascii_table dictionary and prints it as it 
    is the corresponding ascii decimal
    """
    input_str = input("Enter text: ")
    input_list = input_str.split(" ")  

    if input_str == "":
        print("no input")

    #makes sure input accepts letters along with special keyboard characters
    elif all(txt.isalnum() or txt.isspace() or txt in "!@#$%^&*()_+-=[]{}|;:'\",.<>?/" for txt in input_str):

        #defines ascii decimal conversions from chracaters
        ascii_table = {
            0: 'NUL', 1: 'SOH', 2: 'STX', 3: 'ETX', 4: 'EOT', 5: 'ENQ', 6: 'ACK', 7: 'BEL',
            8: 'BS', 9: 'TAB', 10: 'LF', 11: 'VT', 12: 'FF', 13: 'CR', 14: 'SO', 15: 'SI',
            16: 'DLE', 17: 'DC1', 18: 'DC2', 19: 'DC3', 20: 'DC4', 21: 'NAK', 22: 'SYN', 23: 'ETB',
            24: 'CAN', 25: 'EM', 26: 'SUB', 27: 'ESC', 28: 'FS', 29: 'GS', 30: 'RS', 31: 'US',
            32: ' ', 33: '!', 34: '"', 35: '#', 36: '$', 37: '%', 38: '&', 39: "'",
            40: '(', 41: ')', 42: '*', 43: '+', 44: ',', 45: '-', 46: '.', 47: '/',
            48: '0', 49: '1', 50: '2', 51: '3', 52: '4', 53: '5', 54: '6', 55: '7',
            56: '8', 57: '9', 58: ':', 59: ';', 60: '<', 61: '=', 62: '>', 63: '?',
            64: '@', 65: 'A', 66: 'B', 67: 'C', 68: 'D', 69: 'E', 70: 'F', 71: 'G',
            72: 'H', 73: 'I', 74: 'J', 75: 'K', 76: 'L', 77: 'M', 78: 'N', 79: 'O',
            80: 'P', 81: 'Q', 82: 'R', 83: 'S', 84: 'T', 85: 'U', 86: 'V', 87: 'W',
            88: 'X', 89: 'Y', 90: 'Z', 91: '[', 92: '\\', 93: ']', 94: '^', 95: '_',
            96: '`', 97: 'a', 98: 'b', 99: 'c', 100: 'd', 101: 'e', 102: 'f', 103: 'g',
            104: 'h', 105: 'i', 106: 'j', 107: 'k', 108: 'l', 109: 'm', 110: 'n', 111: 'o',
            112: 'p', 113: 'q', 114: 'r', 115: 's', 116: 't', 117: 'u', 118: 'v', 119: 'w',
            120: 'x', 121: 'y', 122: 'z', 123: '{', 124: '|', 125: '}', 126: '~', 127: 'DEL',
        }

        for word in input_list:
            for letter in word:
                try:
                    found = False
                    #looks for corresponding ascii decimal value in dictionary for input
                    for key, value in ascii_table.items():
                        if value == letter:
                            text_ascii = key
                            print(text_ascii)
                            #used to determine when match is found
                            found = True
                            #breaks so terminal doesnt print everyother unit in dict as error
                            break
                    if not found:
                            print("Value not found in ASCII conversions")

                except KeyError:
                    print("Value not found in ascii conversions table")
        
    else:
        print("Invalid input: please enter text")

def text_to_uni():
    """
    converts text to hexadecimal vlaue and adds U+ and 00 in front for unicode format

    uses the same format as text_to_hex function
    """
    input_str = input("Enter text: ")
    input_list = input_str.split(" ")  

    if input_str == "":
        print("no input") 

    #makes sure input accepts letter and special keyboard characters
    elif all(txt.isalnum() or txt.isspace() or txt in "!@#$%^&*()_+-=[]{}|;:'\",.<>?/" for txt in input_str):

        #defines hexadecimal string and ascii converions dictionary
        hexadecimal_value = "123456789ABCDEF"  
        ascii_table = {
            0: 'NUL', 1: 'SOH', 2: 'STX', 3: 'ETX', 4: 'EOT', 5: 'ENQ', 6: 'ACK', 7: 'BEL',
            8: 'BS', 9: 'TAB', 10: 'LF', 11: 'VT', 12: 'FF', 13: 'CR', 14: 'SO', 15: 'SI',
            16: 'DLE', 17: 'DC1', 18: 'DC2', 19: 'DC3', 20: 'DC4', 21: 'NAK', 22: 'SYN', 23: 'ETB',
            24: 'CAN', 25: 'EM', 26: 'SUB', 27: 'ESC', 28: 'FS', 29: 'GS', 30: 'RS', 31: 'US',
            32: ' ', 33: '!', 34: '"', 35: '#', 36: '$', 37: '%', 38: '&', 39: "'",
            40: '(', 41: ')', 42: '*', 43: '+', 44: ',', 45: '-', 46: '.', 47: '/',
            48: '0', 49: '1', 50: '2', 51: '3', 52: '4', 53: '5', 54: '6', 55: '7',
            56: '8', 57: '9', 58: ':', 59: ';', 60: '<', 61: '=', 62: '>', 63: '?',
            64: '@', 65: 'A', 66: 'B', 67: 'C', 68: 'D', 69: 'E', 70: 'F', 71: 'G',
            72: 'H', 73: 'I', 74: 'J', 75: 'K', 76: 'L', 77: 'M', 78: 'N', 79: 'O',
            80: 'P', 81: 'Q', 82: 'R', 83: 'S', 84: 'T', 85: 'U', 86: 'V', 87: 'W',
            88: 'X', 89: 'Y', 90: 'Z', 91: '[', 92: '\\', 93: ']', 94: '^', 95: '_',
            96: '`', 97: 'a', 98: 'b', 99: 'c', 100: 'd', 101: 'e', 102: 'f', 103: 'g',
            104: 'h', 105: 'i', 106: 'j', 107: 'k', 108: 'l', 109: 'm', 110: 'n', 111: 'o',
            112: 'p', 113: 'q', 114: 'r', 115: 's', 116: 't', 117: 'u', 118: 'v', 119: 'w',
            120: 'x', 121: 'y', 122: 'z', 123: '{', 124: '|', 125: '}', 126: '~', 127: 'DEL',
        }

        for word in input_list:
            for letter in word:
                found = False
                #looks for correspoding ascii decmal in dictionary and breaks loop once found
                for key, value in ascii_table.items():
                    if value == letter:
                        text_ascii = key
                        found = True
                        break
                if not found:
                        print("Value not found in ASCII conversions")
                        continue
                try:
                    #converts ascii decimal into seperate digits rem and div and converts each
                    #to heaxadeicmal value by looking for the index the index in the hexadecimal_value
                    #string
                    div = text_ascii // 16
                    rem = text_ascii % 16

                    #minuses 1 to make sure index is accurate when converting to hexadecimal
                    div = div - 1
                    rem = rem - 1

                    div_hex = hexadecimal_value[div]
                    rem_hex = hexadecimal_value[rem]

                    hex = div_hex + rem_hex
                    #defines two different strings for unicode format
                    zero = "00"
                    uni = "U+"

                    #adds strings infront of hexadecimal value to get correct unicode value format
                    text_uni = uni + zero + hex
                    print(text_uni)

                except ValueError:
                    print("Error: trying to convert a non-integer string to an integer")
    else:
        print("Invalid input: please enter text")

def ascii_to_binary():
    """
    takes ascii decimal value and looks for sum in power_list
    takes sums and converts it to one

    takes the rest of digits not used in sum and covnerts it to zero

    does it through every single digit in power_list to get binary output
    """
    input_str = input("Enter ascii decimal: ")
    input_list = input_str.split(" ")

    if input_str == "":
        print("no input")

    #makes sure input is only numbers
    elif all(num.isdigit() for num in input_list):
        #used to find binary digits
        power_list = [64, 32, 16, 8, 4, 2, 1]
        binary_ascii = ""

        for num in input_list:
            #converts string to into to be used in mathimatical equations
            num = int(num)
            #adds zero in beginning of every digit
            binary_num = "0"

            #takes digits in power_list and converts sum to 1
            for power in power_list:
                if num >= power:
                    binary_num += "1"
                    num -= power
                #convers digits not used in sum to 0
                else:
                    binary_num += "0"
            
            #adss unto binary_num string
            binary_ascii += binary_num + " "

        #prints binary value, removing leading spaces
        print(binary_ascii.strip())
    else:
        print("Invalid Input: please input ascii decimal value")

def ascii_to_hex():
    """
    converts ascii decimals to hex by dividing by 16 to get two seperate values
    the dividant and remainder

    takes seperate value and finds the number value as an index in hexadecimal string

    adds both hexaecimal values to get final hex value
    """
    input_str = input("Enter asci decimal: ")
    input_list = input_str.split(" ")  

    if input_str == "":
        print("no input")

    #makes sure user only inputs digits
    elif all(num.isdigit() for num in input_list):
        #defines hexadecimal values in a string
        hexadecimal_value = "123456789ABCDEF"
        for num in input_list:
            try:
                #divides input by 16 to get rem and div
                div = int(num) // 16
                rem = int(num) % 16

                #minuses 1 to get correct index
                div = div - 1
                rem = rem - 1

                #finds index in hex string to get corresponding hexadecimal value
                div_hex = hexadecimal_value[div]
                rem_hex = hexadecimal_value[rem]

                #adds values together to get final hexadecimal of ascii decimal value
                hex = div_hex + rem_hex
                print(hex)

            except IndexError:
                print("Index is out of Range")
    else:
        print("Invalid Input: please input ascii decimal value")        

def ascii_to_text():
    """
    looks for correspoding character value in ascii_table dictionary and prints that
    """
    input_str = input("Enter text: ")
    input_list = input_str.split(" ")  

    if input_str == "":
        print("no input")

    #makes sure all input is numeric
    elif all(num.isdigit() for num in input_list):

        #defined dictionary of all ascii character conversions
        ascii_table = {
            0: 'NUL', 1: 'SOH', 2: 'STX', 3: 'ETX', 4: 'EOT', 5: 'ENQ', 6: 'ACK', 7: 'BEL',
            8: 'BS', 9: 'TAB', 10: 'LF', 11: 'VT', 12: 'FF', 13: 'CR', 14: 'SO', 15: 'SI',
            16: 'DLE', 17: 'DC1', 18: 'DC2', 19: 'DC3', 20: 'DC4', 21: 'NAK', 22: 'SYN', 23: 'ETB',
            24: 'CAN', 25: 'EM', 26: 'SUB', 27: 'ESC', 28: 'FS', 29: 'GS', 30: 'RS', 31: 'US',
            32: ' ', 33: '!', 34: '"', 35: '#', 36: '$', 37: '%', 38: '&', 39: "'",
            40: '(', 41: ')', 42: '*', 43: '+', 44: ',', 45: '-', 46: '.', 47: '/',
            48: '0', 49: '1', 50: '2', 51: '3', 52: '4', 53: '5', 54: '6', 55: '7',
            56: '8', 57: '9', 58: ':', 59: ';', 60: '<', 61: '=', 62: '>', 63: '?',
            64: '@', 65: 'A', 66: 'B', 67: 'C', 68: 'D', 69: 'E', 70: 'F', 71: 'G',
            72: 'H', 73: 'I', 74: 'J', 75: 'K', 76: 'L', 77: 'M', 78: 'N', 79: 'O',
            80: 'P', 81: 'Q', 82: 'R', 83: 'S', 84: 'T', 85: 'U', 86: 'V', 87: 'W',
            88: 'X', 89: 'Y', 90: 'Z', 91: '[', 92: '\\', 93: ']', 94: '^', 95: '_',
            96: '`', 97: 'a', 98: 'b', 99: 'c', 100: 'd', 101: 'e', 102: 'f', 103: 'g',
            104: 'h', 105: 'i', 106: 'j', 107: 'k', 108: 'l', 109: 'm', 110: 'n', 111: 'o',
            112: 'p', 113: 'q', 114: 'r', 115: 's', 116: 't', 117: 'u', 118: 'v', 119: 'w',
            120: 'x', 121: 'y', 122: 'z', 123: '{', 124: '|', 125: '}', 126: '~', 127: 'DEL',
        }
        for num in input_list:
            try:
                #translates value to int to use as index
                digit = int(num)
                if digit in ascii_table:

                    #looks for corresponding character value of ascii decimal input
                    text_ascii = ascii_table[digit]
                    print(text_ascii)
                else:
                    print("Value not found in ASCII conversions")

            except ValueError:
                print("Invalid input: is not a valid ASCII decimal value")
    else:
        print("Invalid Input: please input ascii decimal value")

def ascii_to_uni():
    """
    converts value to hexadecimal but outputs with U+00 in front of hex value
    """
    input_str = input("Enter asci decimal: ")
    input_list = input_str.split(" ")  

    if input_str == "":
        print("no input")

    #makes sure all input is numerical
    elif all(num.isdigit() for num in input_list):
        #definex hesadecimal values
        hexadecimal_value = "123456789ABCDEF"
        for num in input_list:
            try:
                #used to get two seperate values from input (div and rem)
                div = int(num) // 16
                rem = int(num) % 16

                #minuses one to get correct index
                div = div - 1
                rem = rem - 1

                #looks for hexadecimal value in hexstring using index
                div_hex = hexadecimal_value[div]
                rem_hex = hexadecimal_value[rem]

                #adds together to get hex value and ads U+00 in front to get unicode format
                hex = div_hex + rem_hex

                #defines two strings for unicode format
                zero = "00"
                uni = "U+"

                #adds all together to get unicode value
                uni_ascii = uni + zero + hex
                print(uni_ascii)

            except IndexError:
                print("Index is out of Range")
    else:
        print("Invalid Input: please input ascii decimal value")      

def uni_to_binary():
    """
    same method as converting hexadecimal to bianry but uses  four seperate diggtis instead
    of two due to unicode format being a len of 4 without U+
    """
    try:
        input_str = input("Enter unicode with a space after each one: ")
        input_list = input_str.split(" ")
        input_list = [value.upper() for value in input_list]

        if input_str == "":
            print("no input: Please input unicode")

        #makes sure value accepts input that only start with U+
        elif input_str.startswith("U+") :

            #removes U+ after statement because we wont need it for the calculations
            input_list = [value.strip("U+") for value in input_list]

            #defines hex string and power list for binary
            hex_values = "0123456789ABCDEF"
            power_list = [8, 4, 2, 1]

            for value in input_list:
                binary_num = ""
                binary_num_2 = ""
                binary_num_3 = ""
                binary_num_4 = ""

                #seperates each digit in input by indes
                div = value[0]
                rem = value[1]
                div2 = value[2]
                rem2 = value[3]

                #gets the numeric value of inputs from hex string format
                find_div = hex_values.index(div)
                find_rem = hex_values.index(rem)
                find_div2 = hex_values.index(div2)
                find_rem2 = hex_values.index(rem2)

                #takes sums in power_list that equal seperate digits from the numeric values
                #and turns it to one

                #and the rest that arent in the sum are turned to 0
                for power in power_list:
                    if find_div >= power:
                        binary_num += "1"
                        find_div -= power
                    else:
                        binary_num += "0"

                    if find_rem >= power:
                        binary_num_2 += "1"
                        find_rem -= power
                    else:
                        binary_num_2 += "0"

                    if find_div2 >= power:
                        binary_num_3 += "1"
                        find_div2 -= power
                    else:
                        binary_num_3 += "0"

                    if find_rem2 >= power:
                        binary_num_4 += "1"
                        find_rem2 -= power
                    else:
                        binary_num_4 += "0"

                #takes all binary digits of each seperate string sna djoins them together
                #to get binary value of unicode
                binary = binary_num + binary_num_2 + binary_num_3 + binary_num_4
                print(binary)
        else:
            print("Invalid input: Please enter unicode")    

    except ValueError:
        print("Error: Please put spaces between each unicode")


def uni_to_text():
    """
    removes U+ from input
    seperate into four digits and handle each seperatly 
    converts to binary

    converts from binary to ascii decimals

    converts from ascii decimals to text using chr function
    """
    try:
        input_str = input("Enter unicode with a space after each one: ")
        input_list = input_str.split(" ")
        input_list = [value.upper() for value in input_list]

        if input_str == "":
            print("no input: Please input unicode")

        #makes sure input starts with U+ for unicode format
        elif input_str.startswith("U+") :

            #removes U+ from input because it is not needed
            input_list = [value.strip("U+") for value in input_list]

            #defines hex values fir hexadecimal and power list for binary
            hex_values = "0123456789ABCDEF"
            power_list = [8, 4, 2, 1]

            for value in input_list:
                binary_num = ""
                binary_num_2 = ""
                binary_num_3 = ""
                binary_num_4 = ""

                #seperates into individual digits using index
                div = value[0]
                rem = value[1]
                div2 = value[2]
                rem2 = value[3]
                
                #converts to numeric value in hex string using index
                find_div = hex_values.index(div)
                find_rem = hex_values.index(rem)
                find_div2 = hex_values.index(div2)
                find_rem2 = hex_values.index(rem2)

                #takes numeric value and looks for sum in power_list
                for power in power_list:
                    if find_div >= power:
                        #takes sum and in numeric value and converts to one
                        binary_num += "1"
                        find_div -= power
                    else:
                        #takes remainign digits not used in sum and converts to 0
                        binary_num += "0"
                #repeats this process for each individual digit getting the binary value 
                #of each digit
                    if find_rem >= power:
                        binary_num_2 += "1"
                        find_rem -= power
                    else:
                        binary_num_2 += "0"

                    if find_div2 >= power:
                        binary_num_3 += "1"
                        find_div2 -= power
                    else:
                        binary_num_3 += "0"

                    if find_rem2 >= power:
                        binary_num_4 += "1"
                        find_rem2 -= power
                    else:
                        binary_num_4 += "0"
                
                binary = binary_num + binary_num_2 + binary_num_3 + binary_num_4
                #makes sure length of binary is 8 digits
                for digits in range(0, len(binary), 8):
                    num = binary[digits:digits + 8]

                    #converts to ascii decimal byt timsing index of binary by power of 2
                    index7 = int(num[7]) * 1
                    index6 = int(num[6]) * 2
                    index5 = int(num[5]) * 4
                    index4 = int(num[4]) * 8
                    index3 = int(num[3]) * 16
                    index2 = int(num[2]) * 32
                    index1 = int(num[1]) * 64
                    index0 = int(num[0]) * 128

                    add = index7 + index6 + index5 + index4 + index3 + index2 + index1 + index0

                    #takes ascii decimal and converts to text by using chr finction instead of picking from dict
                    print(chr(add))    

        else:
            print("Invalid input: Please enter unicode")    

    except :
        print("Error: Please put spaces between each unicode.")

def uni_to_ascii():
    """
    removes U+ from input

    seperates into individual digit from input

    looks for digit index in hex string

    takes digit index and converts to binary using power_list for sum

    multiplies binary index by correpsonding power to get ascii decimal value

    adds all together to get final ascii decimal value
    """
    try:
        input_str = input("Enter unicode with a space after each one: ")
        input_list = input_str.split(" ")
        input_list = [value.upper() for value in input_list]

        if input_str == "":
            print("no input: Please input unicode")

        #makes sure input only accepts value starting with U+
        elif input_str.startswith("U+") :

            #removes U+ from inout because it is not needed
            input_list = [value.strip("U+") for value in input_list]

            #defines hex values for numeric index and power list for binary
            hex_values = "0123456789ABCDEF"
            power_list = [8, 4, 2, 1]

            for value in input_list:
                #makes sure to add leading zeros if len is not up to 4
                value = "{:04}".format(value)
                binary_num = ""
                binary_num_2 = ""
                binary_num_3 = ""
                binary_num_4 = ""

                #seperates input into indiviual digits and converts them individually
                div = value[0]
                rem = value[1]
                div2 = value[2]
                rem2 = value[3]

                #looks for numeric value of digits in hexadecimal using index
                find_div = hex_values.index(div)
                find_rem = hex_values.index(rem)
                find_div2 = hex_values.index(div2)
                find_rem2 = hex_values.index(rem2)

                
                #converts to binary by taking sums that equal numeric value and turnin them to one
                #and takes the non sum digits and convert them ti 0
                for power in power_list:
                    if find_div >= power:
                        binary_num += "1"
                        find_div -= power
                    else:
                        binary_num += "0"

                    if find_rem >= power:
                        binary_num_2 += "1"
                        find_rem -= power
                    else:
                        binary_num_2 += "0"

                    if find_div2 >= power:
                        binary_num_3 += "1"
                        find_div2 -= power
                    else:
                        binary_num_3 += "0"

                    if find_rem2 >= power:
                        binary_num_4 += "1"
                        find_rem2 -= power
                    else:
                        binary_num_4 += "0"
                
                binary = binary_num + binary_num_2 + binary_num_3 + binary_num_4

                #makes sure binarey digit equals 8 lengths
                for digits in range(0, len(binary), 8):
                    num = binary[digits:digits + 8]

                    #turns to ascii decimal by mutliplying binary index by power of 2
                    index7 = int(num[7]) * 1
                    index6 = int(num[6]) * 2
                    index5 = int(num[5]) * 4
                    index4 = int(num[4]) * 8
                    index3 = int(num[3]) * 16
                    index2 = int(num[2]) * 32
                    index1 = int(num[1]) * 64
                    index0 = int(num[0]) * 128

                    #adds all ne indexes to get ascii decimal value
                    add = index7 + index6 + index5 + index4 + index3 + index2 + index1 + index0
                    print(add, ":This is the ascii decimal value of the 2-by-2 hexadecimal values in the 4 digit unicode")

    except ValueError:
        print("Error: Please put spaces between each unicode.")

def uni_to_hex():
    """
    takes input and removes U+ to get hexadecimal format
    """
    try:
        input_str = input("Enter unicode with a space after each one: ")
        input_list = input_str.split(" ")
        input_list = [value.upper() for value in input_list]

        if input_str == "":
            print("no input: Please input unicode")

        #makes sure only accept input starting with U+
        elif input_str.startswith("U+") :

            #removes U+ and replaces with empty string as we dont need it anymore
            input_list = [value.replace("U+","") for value in input_list]

            for value in input_list:
                
                #seperates each digit in input individually
                first = value[0]
                second = value[1]
                third = value[2]
                four = value[3]

                #adds to get hexadecimal value in correct format (2 by 2 not a 4 digit)
                first_digit = first + second
                second_digit = third + four

                #prints correctly formatted hexadecimal valye
                print(first_digit, second_digit)
        else:
                print("Invalid input: Please enter Unicode")    

    except ValueError:
        print("Error: Please put spaces between each Unicode.")


