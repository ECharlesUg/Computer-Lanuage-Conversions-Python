
## Binary to Hexadecimal:
Input (Binary): 11111111 10101111 01111110
Output (Hexadecimal): "FF AF 7E"

## Binary to Text (ASCII):
Input (Binary): 01001000 01100101 01101100 01101100 01101111
Output (Text): "Hello"

## Binary to ASCII:
Input (Binary): 01001001 01100010 01100011 01101100 01101001
Output (ASCII): "73 98 99 108 105"

## Binary to Unicode (U+XXXX):
Input (Binary): 11011000 10110101 10111110 10011110
Output (Unicode): "U+00D8 U+00B5 U+00BE U+009E"

## Hexadecimal to Binary:
Input (Hexadecimal): A3
Output (Binary): "100011"

## Hexadecimal to Text (ASCII):
Input (Hexadecimal): 48 65 6C 6C 6F
Output (Text): "Hello"

## Hexadecimal to ASCII:
Input (Hexadecimal): 47 6F 6F 64 62 75 79 65
Output (ASCII): "71 111 111 100 98 117 121 101"

## Hexadecimal to Unicode (U+XXXX):
Input (Hexadecimal): 1F 60
Output (Unicode): "U+001F U+0060"

## Text to Binary:
Input (Text): "hello"
Output (Binary): "01001000 01100101 01101100 01101100 01101111"

## Text to Hexadecimal:
Input (Text): "world"
Output (Hexadecimal): "77 6F 72 6C 64"

## Text to ASCII:
Input (Text): "example"
Output (ASCII): "101 120 97 109 112 108 101"

## Text to Unicode (U+XXXX):
Input (Text): "hello"
Output (Unicode): "U+0068 U+0065 U+006C U+006C U+006F"

## Unicode to Binary:
Input (Unicode): U+0048 U+0065 U+006C U+006C U+006F
Output (Binary): "0000000001001000 0000000001100101 0000000001101100 0000000001101100 0000000001101111"

## Unicode to Hexadecimal:
Input (Unicode): U+1F60 U+0041 U+005A
Output (Hexadecimal): "1F 60 00 41 00 5A"

## Unicode to Text (U+XXXX):
Input (Unicode): U+0048 U+0065 U+006C U+006C U+006F
Output (Text): "H e l l o"

## Unicode to ASCII:
Input (Unicode): U+0048 U+0065 U+006C U+006C U+006F
Output (ASCII): "72 101 108 108 111"

## Ascii to Binary
Input (Ascii): 65	
Output (Binary): "01000001"	

## Ascii to Hexadecimal
Input (Ascii): 122 
Output (Hexadecimal): "7A"

## Ascii to Text
Input (Ascii): 33
Output (Text): "!"

## Ascii to Unicode
Input (Ascii): 126
Output (Unicode): "U+007E"
