# Binary to Hexadecimal
### start
Function: Binary to hexa decimal
Input: Binary_string
Output: Hex_value

steps:
1. declare variable
  - hexadecimal_value equals "123456789ABCDEF"
  - 10 to 15 equals range(A,F)
  - binary_string equals input

  - div equals binary_string divided by 10000
  - rem equals binary_string remainder of division by 10000

starting from the right of the rem and div value

2. Calculate for digits
  - for digits in rem and div 
    - index0 up till index3 equals digits index0 to index3 times increasing power of 2^0 till 2^3

    - add(rem) equals sum of all the indexes of digits 
  
    - add(div) equals sum of all the indexes of digits 


3. Finalize variables and output
  - add(rem) equals add(rem) index found in hexadecimal_value
  
  - add(div) equals add(div) index found in hexadecimal_value

  hex_value equals add(rem).append(add(div))

  - print hex_value
### end

# Binary to Text
### Start
Function: Binary to text
Input: Binary_string
Output: text_value

1. Declare variables
  - converter equals binary to char using ASCII conversion
  - input binary_string
  - starting from the right side of input

2. Calculate digits
  - for digits in binary_string:
     - all indexes from 0 to 7 equals indexes from 0 to 7 in digits time 2^0 to 2^7 reversing 
  
     - in decending order against digit index in ascending order.

  sum equals sum of all digits in all indexes

3. Convert Values and calculate output
  - text_value equals sum in converter
  - print text_value 
### End

# Binary to ASCII
### start
Function: Binary to ascii
Input: Binary_string
Output: ascii_sum

1. Declare variables
  - converter equals binary to ascii value using ASCII conversion
  - input binary_string
  - starting from the right side of input

2. Calculate digits
  - for digits in binary_string:
     - all indexes from 0 to 7 equals indexes from 0 to 7 in digits time 2^0 to 2^7 reversing 
  
     - in decending order against digit index in ascending order.

  ascii_sum equals sum of all digits in all indexes

3. Convert Values and calculate output
  - print ascii_sum
### end

# Binary to Unicode
### start
Function: Binary to Unicode
Input: Binary_string
Output: Uni_value

steps:
1. declare variable
  - hexadecimal_value equals "123456789ABCDEF"
  - 10 to 15 equals range(A,F)
  - binary_string equals input

  - div equals binary_string divided by 10000
  - rem equals binary_string remainder of division by 10000

starting from the right of the rem and div value

2. Calculate for digits
  - for digits in rem and div 
    - index0 up till index3 equals digits index0 to index3 times increasing power of 2^0 till 2^3

    - add(rem) equals sum of all the indexes of digits 
  
    - add(div) equals sum of all the indexes of digits 


3. Finalize variables and output
  - add(rem) equals add(rem) index found in hexadecimal_value
  
  - add(div) equals add(div) index found in hexadecimal_value

  hex_value equals add(rem).append(add(div))

4. Add final digits unto hex value
   zero equals "00"
   Uni equals "U+"

   Uni_value equals uni plus zero plus hex_value
   print Uni_value

### end

# Hex to Binary
### start
 Function: hex to binary
 Input: hex_str
 Output: binary_all_sum
 hexadecimal_value equals "123456789ABCDEF"

1. Declare Variable
  - hex_str equals input
  - hex_str equals input.index(0)
  - num2 equals input.index(1)

2. Calculate Digits
  - hex = hex_str in hexadecimal_value
  - hex2 = num2 in hexadecimal_value
  
  - find equals find sum of numbers in 8, 4, 2, 1 that equal hex2 and hex1 equal "1"
  
  - binary_all_sum equals digit in sum of numbers that does not equal hex2 and hex1 equals "0"

3. Finalize output
 - print binary_all_sum.append(find)
### end

# Hex to text
### start
Function: Hex to text
Input: hex_string
Output: text

1. Declare Variables
 - hexadecimal_value equals "123456789ABCDEF"
 - coverter equals binary to ASCII char(text) using ASCII conversion table

 - hex_string equals input
 - hex_string equals input.index(0)
 - num2 equals input.index(1)

 - hex equals hex_string index in hexadecimal_value
 - hex2 equals num2 index in hexadecimal_value

2. Calculate variables 
  - find equals find sum of numbers in 8, 4, 2, 1 that equal hex2 and hex1
  
  - all_sum equals digits in sum of numbera that does not equal hex2 and hex1 equals 0

 - for digits in (all_sum plus find)
  index0 to index 4 equals digit index of 0 to 4 times 2^0 to 2^3

3. Finalize output
  - add equals sum of all index in all sum
  - text equals add in converter
  print text 
### end

# Hex to ASCII
### start
Function: Hex to ascii
Input: hex_string
Output: ascii_add

1. Declare Variables
 - hexadecimal_value equals "123456789ABCDEF"
 - coverter equals binary to ASCII char(text) using ASCII conversion table
 - list = [64,32,16,8, 4, 2, 1]

 - hex_string equals input
 - hex_string equals input.index(0)
 - num2 equals input.index(1)

 - hex equals hex_strinf index in hexadecimal_value
 - hex2 equals num2 index in hexadecimal_value

2. Calculate variables 
  - find equals find sum of numbers in list that equal hex2 and hex1
  
  - all_sum equals digits in sum of numbera that does not equal hex2 and hex1 equals 0

 - for digits in (all_sum + find)
  index0 to index 4 equals digit index of 0 to 4 times 2^0 to 2^3

3. Finalize output
  - ascii_add equals sum of all index in all sum
  print ascii_add
### end

# Hex to Unicode
### start
Function: Hex to uni
Input: hex_string
Output: hex_uni

hex_string equals input

for value in hex_string
zero equals "00"
unit equals "U+"
hex_uni equals unit plus zero plus hex_string

print hex_uni
 
### end

# Text to Binary
### start
Function: Text to Binary
Input: text_string
Output: Binary

1. Declare Variable
   - list equals [64,32,16,8,4,2,1]
   - text_string equals input
   - converter equals ascii codes conversions

2. Calculate digits
   - for letters in text_string
   text_ascii equals letters in converter

   - the sum of numbers in list that equal text_ascii: equals 1
   - the rest of the numbers in list: equals 0

3. Finalize output
   - binary equals sum of numbers.append(rest of numbers)
   print binary 

### end

# Text to Hex
### start
Function: Text to Hex
Input: text_string
Output: Hex

1. Declare Variables
- convert equals char to asci codes conversions
- hexadecimal_value equals "12345678ABCDEF
- text_string equals input
- text_ascii equals text_string in convert

2. Calculate variables and digits
- div equals test_ascii divided 16
- rem equals test_ascii remainder divided by 16

- div_hex equals div in hexadecimal_value
- rem_hex equals rem in hexadecimal_value

3. Finalize output
- hex equals div_hex.append(rem_hex)
print hex 
### end

# Text to ASCII 
### start
Function: Text to ascii
Input: text_string
Output: text_ascii

1. Declare Variables
- convert equals ASCII code converions
- text_string equals input

2. Calculate Variables and digits
- for letters in text_string
- text_ascii equals letters in convert

3. Finalize variable
print text_ascii
### end

# Text to Uni
### start
Function: Text to uni
Input: text_string
Output: text_uni

1. Declare Variables
- convert equals char to asci codes conversions
- hexadecimal_value equals "12345678ABCDEF
- text_string equals input
- text_ascii equals text_string in convert

2. Calculate variables and digits
- div equals test_ascii divided 16
- rem equals test_ascii remainder divided by 16

- div_hex equals div in hexadecimal_value
- rem_hex equals rem in hexadecimal_value

3. Finalize output
- hex equals div_hex.append(rem_hex)
   zero equals "00"
   unit equals "U+"
   text_uni equals unit plus zero plus hex

   print text_uni

### end

# Ascii to Binary
### start
Function: ascii to binary
Input: ascii_string
Output: Binary

1. Declare Variable
list equals [64,32,16,8,4,2,1]

ascii_string equals input

2. Calculate variables 
- num equals numbers added in list that equal to ascii_string equals "1"

- rem equals numbers added in list that dont equal ascii_string equals "0"

1. Finalize output
- bin_sum equals num.append(rem)

 print bin_num
### end

# Ascii to Hex
### start
Function: ascii to hex
Input: ascii_string
Output: hex

1. Declare Variable
  hexadecimal_value = "123456789ABCDEF"

  ascii_string = input

2. Calculate variables and digits
   - div equals ascii_string divided 16
     
   - rem equals ascii_string remainder divided by 16

   - div_hex equals div in hexadecimal_value
     
   - rem_hex equals rem in hexadecimal_value

3. Finalize output
   - hex equals div_hex.append(rem_hex)
   print hex 
### end

# Ascii to Text
### start
Function: ascii to text
Input: ascii_string
Output: text

1. Declare Variables
- convert equals ASCII code converions(dictionary)
- ascii_string equals input

2. Calculate Variables and digits
- for num in ascii_string
- text equals num in convert

3. Finalize variable
print text
### end

# Ascii to Uni
### start
Function: ascii to uni
Input: ascii_string
Output: ascii_uni

1. Declare Variable
  hexadecimal_value = "123456789ABCDEF"

  ascii_string= input

2. Calculate variables and digits
   - div equals ascii_string divided 16
     
   - rem equals ascii_string remainder divided by 16

   - div_hex equals div in hexadecimal_value
     
   - rem_hex equals rem in hexadecimal_value

3. Finalize output
   - hex equals div_hex.append(rem_hex)
   zero equals "00"
   unit equals "U+"
   ascii_uni equals unit plus zero plus hex

   print ascii_uni
### end

# Unicode to Binary
### start
 Function: uni to binary
 Input: uni_str
 Output: binary_all_sum
 hexadecimal_value equals "123456789ABCDEF"

1. Declare Variable
  - uni_string equals input
    uni_rem equals uni_str.remove("U+00")

  - uni_rem equals input.index(0)
  - num2 equals input.index(1)

2. Calculate Digits
  - uni = uni_rem in hexadecimal_value
  - uni2 = num2 in hexadecimal_value
  
  - find equals find sum of numbers in 8, 4, 2, 1 that equal uni2 and uni equal "1"
  
  - binary_all_sum equals digit in sum of numbers that does not equal uni2 and uni equals "0"

3. Finalize output
 - print binary_all_sum.append(find)
### end

# Unicode to text
### start
Function: uni to text
Input: uni_string
Output: text

1. Declare Variables
 - hexadecimal_value equals "123456789ABCDEF"
 - coverter equals binary to ASCII char(text) using ASCII conversion table

   - uni_string equals input
    -uni_rem equals uni_str.remove("U+00")
 - num2 equals input.index(1)

 - uni equals uni_rem index in hexadecimal_value
 - uni2 equals num2 index in hexadecimal_value

2. Calculate variables 
  - find equals find sum of numbers in 8, 4, 2, 1 that equal uni2 and uni
  
  - all_sum equals digits in sum of numbers that does not equal uni2 and uni equals 0

 - for digits in (all_sum plus find)
  index0 to index 4 equals digit index of 0 to 4 times 2^0 to 2^3

3. Finalize output
  - add = sum of all index in all sum
  - text = add in converter
  print text 
### end

# Unicode to ASCII
### start
Function: uni to ascii
Input: uni_string
Output: ascii_add

1. Declare Variables
 - hexadecimal_value equals "123456789ABCDEF"
 - coverter equals binary to ASCII char(text) using ASCII conversion table
 - list = [64,32,16,8, 4, 2, 1]


 - uni_string equals input
  -uni_rem equals uni_str.remove("U+00")
 - num2 equals input.index(1)

 - uni equals uni_rem index in hexadecimal_value
 - uni2 equals num2 index in hexadecimal_value

2. Calculate variables 
  - find equals find sum of numbers in 8, 4, 2, 1 that equal uni2 and uni
  
  - all_sum equals digits in sum of numbers that does not equal uni2 and uni equals 0


 - for digits in (all_sum plus find)
  index0 to index 4 equals digit index of 0 to 4 times 2^0 to 2^3

3. Finalize output
  - ascii_add = sum of all index in all_sum
  print ascii_add
### end

# Unicode to Hex
### start
Function: uni to Hex
Input: uni_string
Output: hex_uni

uni_string equals input

for value in uni_string
uni_rem equals uni_string.remove("U+00")
hex_uni = equals uni_rem

print hex_uni
### end