from conversions import binary_to_hex
from conversions import binary_to_text
from conversions import binary_to_ascii
from conversions import binary_to_uni
from conversions import hex_to_binary
from conversions import hex_to_text
from conversions import hex_to_ascii
from conversions import hex_to_uni
from conversions import text_to_binary
from conversions import text_to_hex
from conversions import text_to_ascii
from conversions import ascii_to_binary
from conversions import ascii_to_hex
from conversions import ascii_to_text
from conversions import text_to_uni
from conversions import ascii_to_uni
from conversions import uni_to_binary
from conversions import uni_to_hex
from conversions import uni_to_ascii
from conversions import uni_to_text

running = True
while running:
    def menu():
        print("Menu")
        print("Welcome to the Multi-Format Conversion Tool!")
        print("1. Convert from Binary")
        print("2. Convert from Hex")
        print("3. Convert from text")
        print("4. Convert from ASCII")
        print("5. Convert from Unicode")
        print("6. Exit")
        input_str = input("Enter option number: ")

        if input_str == "1":
            print("Which conversion would u like: ")
            print("1. Convert Binary to Hex")
            print("2. Convert Binary to text")
            print("3. Convert Binary to ASCII")
            print("4. Convert Binary to Unicode")
            print("5. Return to Menu")
            input_str = input("Enter option number: ")

            if input_str == "1":
                binary_to_hex()
            elif input_str == "2":
                binary_to_text()
            elif input_str == "3":
                binary_to_ascii()
            elif input_str == "4":
                binary_to_uni()
            elif input_str == "5":
                return

        elif input_str == "2":
            print("Which conversion would u like: ")
            print("1. Convert Hex to Binary")
            print("2. Convert Hex to text")
            print("3. Convert Hex to ASCII")
            print("4. Convert Hex to Unicode")
            print("5. Return to Menu")
            input_str = input("Enter option number: ")

            if input_str == "1":
                hex_to_binary()
            elif input_str == "2":
                hex_to_text()
            elif input_str == "3":
                hex_to_ascii()
            elif input_str == "4":
                hex_to_uni()
            elif input_str == "5":
                return


        elif input_str == "3":
            print("Which conversion would u like: ")
            print("1. Convert Text to Binary")
            print("2. Convert Text to Hex")
            print("3. Convert Text to ASCII")
            print("4. Convert Text to Unicode")
            print("5. Return to Menu")
            input_str = input("Enter option number: ")

            if input_str == "1":
                text_to_binary()
            elif input_str == "2":
                text_to_hex()
            elif input_str == "3":
                text_to_ascii()
            elif input_str == "4":
                text_to_uni()
            elif input_str == "5":
                return

        elif input_str == "4":
            print("Which conversion would u like: ")
            print("1. Convert Ascii to Binary")
            print("2. Convert Ascii to Hex")
            print("3. Convert Ascii to Text")
            print("4. Convert  Ascii to Unicode")
            print("5. Return to Menu")
            input_str = input("Enter option number: ")

            if input_str == "1":
                ascii_to_binary()
            elif input_str == "2":
                ascii_to_hex()
            elif input_str == "3":
                ascii_to_text()
            elif input_str == "4":
                ascii_to_uni()
            elif input_str == "5":
                return
        
        
        elif input_str == "5":
            print("Which conversion would u like: ")
            print("1. Convert Unicode to Binary")
            print("2. Convert Unicode to Hex")
            print("3. Convert Unicode to Text")
            print("4. Convert Unicode to Ascii")
            print("5. Return to Menu")
            input_str = input("Enter option number: ")

            if input_str == "1":
                uni_to_binary()
            if input_str == "2":
                uni_to_hex()
            if input_str == "3":
                uni_to_text()
            if input_str == "4":
                uni_to_ascii()
            elif input_str == "5":
                return

        elif input_str == "6":
            print("Exiting the program. Goodbye!")
            return False

        else:
            print("Invalid option please select number from given options:")

    menu()
